
var map = new naver.maps.Map(document.getElementById('map'), {
        center: new naver.maps.LatLng(37.56648, 126.97787),
        zoom: 12,
        minZoom: 8,
        maxZoom: 15,
        mapTypeId: 'normal',
        zoomControl: true,
        zoomControlOptions: {
            position: naver.maps.Position.TOP_RIGHT
        },
        mapTypeControl: false,
        mapTypeControlOptions: {
            //style: naver.maps.mapTypeControlStyle.BUTTON,
            position: naver.maps.Position.TOP_RIGHT
        },
        scaleControl: true,
        scaleControlOptions: {
            position: naver.maps.Position.BOTTOM_RIGHT
        },
        logoControl: false,
        logoControlOptions: {
            position: naver.maps.Position.BOTTOM_LEFT
        },
        mapDataControl: true,
        mapDataControlOptions: {
            position: naver.maps.Position.BOTTOM_LEFT
        }
});


