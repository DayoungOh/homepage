$(document).ready(function () {

        //검색창 클릭하면 하단 div show
        $('.search').click(function () {
          $('.search_show').toggleClass('on');
        });

        //왼쪽 사이드 바
        $('.n1 button').click(function () {

          $('.side1').css('display', 'block');
          $('.side2').css('display', 'none');
          $('.side3').css('display', 'none');
          //사이드탭 열기

          $('.left .nav > ul > li').removeClass('on');
          $(this).parent().addClass('on');
          //ad class on으로 현재 nav 표시 

          $('.left .nav .close').addClass('on');
          //닫기버튼 show

          $('.nav-OverlayContainer').addClass('right');
          $('.search_show').addClass('right');
          //사이드바 클릭시 오른쪽으로 이동 클래스 추가

        });


        $('.n2 button').click(function () {

          $('.side1').css('display', 'none');
          $('.side2').css('display', 'block');
          $('.side3').css('display', 'none');
          //사이드탭 열기    

          $('.left .nav > ul > li').removeClass('on');
          $(this).parent().addClass('on');
          //ad class on으로 현재 nav 표시

          $('.left .nav .close').addClass('on');
          //닫기버튼 show

          $('.nav-OverlayContainer').addClass('right');
          $('.search_show').addClass('right');
          //사이드바 클릭시 오른쪽으로 이동 클래스 추가

        });


        $('.n3 button').click(function () {

          $('.side1').css('display', 'none');
          $('.side2').css('display', 'none');
          $('.side3').css('display', 'block');
          //사이드탭 열기    

          $('.left .nav > ul > li').removeClass('on');
          $(this).parent().addClass('on');
          //ad class on으로 현재 nav 표시

          $('.left .nav .close').addClass('on');
          //닫기버튼 show

          $('.nav-OverlayContainer').addClass('right');
          $('.search_show').addClass('right');
          //사이드바 클릭시 오른쪽으로 이동 클래스 추가

        });

        //왼쪽 들어가기 화살표 클릭시 효과
        $('.left .nav .close a').click(function () {

          $('.side-bar').css('display', 'none');
          $(this).parent().removeClass('on');
          //사이드바 닫기

          $('.nav-OverlayContainer').removeClass('right');
          $('.search_show').removeClass('right');
          //상단 float 요소들 오른쪽으로 이동

        });

        //지도에 표시될 SVG 컬러 보기
        $('.click_tag input').click(function () {
          $('.svg_temp_box').css('display', 'block');
        });

        //모달창 열고닫기
        $('.temp_iframe .close a').click(function () {
          $('.modal').css('display', 'none');
        });
        $('.widgetMapInfo button').click(function () {
          $('.modal').css('display', 'block');
        });

        //도움말 창 열기
        $('.help button').click(function () {
          $('.help_show').css('display', 'block');
        });
        //도움말 창 닫기
        $('.help_show button').click(function () {
          $('.help_show').css('display', 'none');
        });
        $('.help_tab li').click(function () {
          $('.help_tab li').removeClass('on');
          $(this).addClass('on');
        });
        $('.help_tab li:nth-child(1)').click(function () {
          $('.tab_show').removeClass('on');
          $('.show1').addClass('on');
        });
        $('.help_tab li:nth-child(2)').click(function () {
          $('.tab_show').removeClass('on');
          $('.show2').addClass('on');
        });
        $('.help_tab li:nth-child(3)').click(function () {
          $('.tab_show').removeClass('on');
          $('.show3').addClass('on');
        });
        $('.help_tab li:nth-child(4)').click(function () {
          $('.tab_show').removeClass('on');
          $('.show4').addClass('on');
        });
        $('.help_tab li:nth-child(5)').click(function () {
          $('.tab_show').removeClass('on');
          $('.show5').addClass('on');
        });

        //창 세로 크기에 따른 report 크기 변화
        var height = $('.temp_iframe').height();
        $('.r_section').css('height', height - 75);

        $(window).resize(function () {
          var height = $('.temp_iframe').height();
          $('.r_section').css('height', height - 75);
        });



      });